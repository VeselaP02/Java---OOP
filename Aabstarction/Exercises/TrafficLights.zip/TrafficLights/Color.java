package Aabstarction.Exercises.TrafficLights;

public enum Color {
    RED,GREEN,YELLOW;
}
